# toc-pdf
Generate bookmarks for pdf using the table of contents. This project is still in development phase and may not work as expected all the time.
